/* @ds-bundle: {"format":3,"namespace":"NotelyDesignSystem_fd4cb3","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Divider","sourcePath":"components/core/Divider.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Tooltip","sourcePath":"components/core/Tooltip.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"EmptyState","sourcePath":"components/feedback/EmptyState.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Skeleton","sourcePath":"components/feedback/Skeleton.jsx"},{"name":"Spinner","sourcePath":"components/feedback/Spinner.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"SearchField","sourcePath":"components/forms/SearchField.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Card","sourcePath":"components/layout/Card.jsx"},{"name":"Modal","sourcePath":"components/layout/Modal.jsx"},{"name":"Tabs","sourcePath":"components/layout/Tabs.jsx"},{"name":"ChecklistItem","sourcePath":"components/notes/ChecklistItem.jsx"},{"name":"EditorToolbar","sourcePath":"components/notes/EditorToolbar.jsx"},{"name":"FolderItem","sourcePath":"components/notes/FolderItem.jsx"},{"name":"NoteCard","sourcePath":"components/notes/NoteCard.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"540f1639afd5","components/core/Badge.jsx":"5d15abf9b04c","components/core/Button.jsx":"500fa867ec78","components/core/Divider.jsx":"1f47292bf8c3","components/core/IconButton.jsx":"6f8cfd39f1b1","components/core/Tag.jsx":"9a0efe6e8cee","components/core/Tooltip.jsx":"8fae044be78a","components/feedback/Alert.jsx":"fafe50c03ac5","components/feedback/EmptyState.jsx":"9ec60b0e5c33","components/feedback/ProgressBar.jsx":"a34c8fafab87","components/feedback/Skeleton.jsx":"a98118b21ab8","components/feedback/Spinner.jsx":"2b8e9e629c5e","components/feedback/Toast.jsx":"96e777f93a30","components/forms/Checkbox.jsx":"756088bed021","components/forms/Input.jsx":"6a31dc5f1260","components/forms/Radio.jsx":"9e95c85f4530","components/forms/SearchField.jsx":"fc84e313da8a","components/forms/Select.jsx":"64a30feb87b8","components/forms/Switch.jsx":"f5bee19260bc","components/layout/Card.jsx":"950d0bfe15a3","components/layout/Modal.jsx":"36ea1eff7884","components/layout/Tabs.jsx":"bde8a22faf4d","components/notes/ChecklistItem.jsx":"e8f81488a1d9","components/notes/EditorToolbar.jsx":"089ef9c5da3c","components/notes/FolderItem.jsx":"845dfcecff9b","components/notes/NoteCard.jsx":"d4bc5b146238","ui_kits/notely-app/App.jsx":"e5cff2cae656","ui_kits/notely-app/EditorView.jsx":"b7858ad34d83","ui_kits/notely-app/NotesView.jsx":"8176599e022d","ui_kits/notely-app/SettingsView.jsx":"03027147070a","ui_kits/notely-app/Sidebar.jsx":"53903bbeecad","ui_kits/notely-app/data.js":"e04cba8513b1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NotelyDesignSystem_fd4cb3 = window.NotelyDesignSystem_fd4cb3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Avatar — user image with initials fallback and optional status dot. */
function Avatar({
  src,
  name = "",
  size = "md",
  status,
  style,
  ...rest
}) {
  const sizes = {
    xs: 22,
    sm: 28,
    md: 34,
    lg: 44,
    xl: 64
  };
  const px = sizes[size] || sizes.md;
  const initials = name.split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
  // deterministic hue from name
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
  const hue = Math.abs(hash) % 360;
  const statusColors = {
    online: "var(--color-success)",
    away: "var(--color-warning)",
    offline: "var(--color-text-tertiary)"
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      width: px,
      height: px,
      flex: "none",
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      objectFit: "cover"
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      width: "100%",
      height: "100%",
      borderRadius: "50%",
      background: `hsl(${hue} 52% 92%)`,
      color: `hsl(${hue} 45% 38%)`,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: px * 0.4,
      fontWeight: "var(--fw-semibold)"
    }
  }, initials || "?"), status && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      right: -1,
      bottom: -1,
      width: px * 0.28,
      height: px * 0.28,
      minWidth: 8,
      minHeight: 8,
      borderRadius: "50%",
      background: statusColors[status],
      border: "2px solid var(--color-card)"
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Badge — small status/count label. */
function Badge({
  children,
  tone = "neutral",
  variant = "soft",
  dot = false,
  style,
  ...rest
}) {
  const tones = {
    neutral: {
      soft: ["var(--color-bg)", "var(--color-text-secondary)"],
      solid: ["var(--gray-700)", "#fff"]
    },
    primary: {
      soft: ["var(--color-primary-subtle)", "var(--color-primary)"],
      solid: ["var(--color-primary)", "#fff"]
    },
    success: {
      soft: ["var(--color-success-subtle)", "var(--color-success)"],
      solid: ["var(--color-success)", "#fff"]
    },
    warning: {
      soft: ["var(--color-warning-subtle)", "var(--color-warning)"],
      solid: ["var(--color-warning)", "#fff"]
    },
    danger: {
      soft: ["var(--color-danger-subtle)", "var(--color-danger)"],
      solid: ["var(--color-danger)", "#fff"]
    },
    info: {
      soft: ["var(--color-info-subtle)", "var(--color-info)"],
      solid: ["var(--color-info)", "#fff"]
    }
  };
  const [bg, fg] = (tones[tone] || tones.neutral)[variant];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      height: 20,
      padding: "0 8px",
      background: bg,
      color: fg,
      fontSize: 12,
      fontWeight: "var(--fw-medium)",
      lineHeight: 1,
      borderRadius: "var(--radius-full)",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: "currentColor"
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Notely Button — primary action control.
 * Variants: primary | secondary | ghost | danger
 * Sizes: sm | md | lg
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  leadingIcon,
  trailingIcon,
  fullWidth = false,
  disabled = false,
  loading = false,
  type = "button",
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      h: 30,
      px: 10,
      fs: 13,
      gap: 6,
      icon: 16
    },
    md: {
      h: 36,
      px: 14,
      fs: 14,
      gap: 8,
      icon: 18
    },
    lg: {
      h: 44,
      px: 18,
      fs: 15,
      gap: 8,
      icon: 20
    }
  };
  const s = sizes[size] || sizes.md;
  const variants = {
    primary: {
      background: "var(--color-primary)",
      color: "var(--color-on-primary)",
      border: "1px solid transparent"
    },
    secondary: {
      background: "var(--color-card)",
      color: "var(--color-text)",
      border: "1px solid var(--color-border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--color-text)",
      border: "1px solid transparent"
    },
    danger: {
      background: "var(--color-danger)",
      color: "#fff",
      border: "1px solid transparent"
    }
  };
  const v = variants[variant] || variants.primary;
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  let bg = v.background;
  if (!disabled && variant === "primary") bg = active ? "var(--color-primary-pressed)" : hover ? "var(--color-primary-hover)" : v.background;
  if (!disabled && variant === "danger") bg = hover ? "var(--red-500)" : v.background;
  if (!disabled && (variant === "secondary" || variant === "ghost")) bg = active ? "var(--color-pressed)" : hover ? "var(--color-hover)" : v.background;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled || loading,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      gap: s.gap,
      height: s.h,
      padding: `0 ${s.px}px`,
      width: fullWidth ? "100%" : "auto",
      fontFamily: "var(--font-sans)",
      fontSize: s.fs,
      fontWeight: "var(--fw-medium)",
      lineHeight: 1,
      color: v.color,
      background: bg,
      border: v.border,
      borderRadius: "var(--radius-md)",
      cursor: disabled || loading ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--opacity-disabled)" : 1,
      transform: active && !disabled ? "scale(0.98)" : "scale(1)",
      transition: "background var(--duration-fast) var(--ease-standard), transform var(--duration-fast) var(--ease-standard)",
      outline: "none",
      whiteSpace: "nowrap",
      ...style
    },
    onFocus: e => e.currentTarget.style.boxShadow = "var(--shadow-focus)",
    onBlur: e => e.currentTarget.style.boxShadow = "none"
  }, rest), loading ? /*#__PURE__*/React.createElement(Spinner, {
    size: s.icon
  }) : leadingIcon, children, trailingIcon);
}
function Spinner({
  size = 16
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      border: "2px solid currentColor",
      borderRightColor: "transparent",
      borderRadius: "50%",
      display: "inline-block",
      animation: "notely-spin 0.6s linear infinite"
    }
  });
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Divider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Divider — hairline separator. Horizontal or vertical, optional label. */
function Divider({
  orientation = "horizontal",
  label,
  spacing = 16,
  style,
  ...rest
}) {
  if (orientation === "vertical") {
    return /*#__PURE__*/React.createElement("span", _extends({
      role: "separator",
      "aria-orientation": "vertical",
      style: {
        display: "inline-block",
        width: 1,
        alignSelf: "stretch",
        background: "var(--color-divider)",
        margin: `0 ${spacing}px`,
        ...style
      }
    }, rest));
  }
  if (label) {
    return /*#__PURE__*/React.createElement("div", _extends({
      role: "separator",
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        margin: `${spacing}px 0`,
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--color-divider)"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--color-text-tertiary)",
        fontWeight: "var(--fw-medium)"
      }
    }, label), /*#__PURE__*/React.createElement("span", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--color-divider)"
      }
    }));
  }
  return /*#__PURE__*/React.createElement("hr", _extends({
    role: "separator",
    style: {
      border: "none",
      height: 1,
      background: "var(--color-divider)",
      margin: `${spacing}px 0`,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Divider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Divider.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Notely IconButton — square, icon-only action.
 * Variants: ghost | solid | outline. Sizes map to 16/20/24 icons.
 */
function IconButton({
  icon,
  label,
  variant = "ghost",
  size = "md",
  active = false,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: 28,
    md: 34,
    lg: 40
  };
  const box = sizes[size] || sizes.md;
  const [hover, setHover] = React.useState(false);
  const base = {
    ghost: {
      background: active ? "var(--color-selected)" : "transparent",
      color: active ? "var(--color-primary)" : "var(--color-text-secondary)"
    },
    solid: {
      background: "var(--color-primary)",
      color: "var(--color-on-primary)"
    },
    outline: {
      background: "var(--color-card)",
      color: "var(--color-text)",
      border: "1px solid var(--color-border-strong)"
    }
  }[variant];
  let bg = base.background;
  if (!disabled) {
    if (variant === "ghost") bg = hover ? "var(--color-hover)" : base.background;
    if (variant === "solid") bg = hover ? "var(--color-primary-hover)" : base.background;
    if (variant === "outline") bg = hover ? "var(--color-hover)" : base.background;
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    onFocus: e => e.currentTarget.style.boxShadow = "var(--shadow-focus)",
    onBlur: e => e.currentTarget.style.boxShadow = "none",
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: box,
      height: box,
      color: base.color,
      background: bg,
      border: base.border || "1px solid transparent",
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--opacity-disabled)" : 1,
      transition: "background var(--duration-fast) var(--ease-standard)",
      outline: "none",
      ...style
    }
  }, rest), icon);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Tag — removable label for note tags. Supports a color dot. */
function Tag({
  children,
  color,
  removable = false,
  onRemove,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      height: 24,
      padding: "0 8px",
      background: hover && onClick ? "var(--color-hover)" : "var(--color-bg)",
      border: "1px solid var(--color-border)",
      color: "var(--color-text-secondary)",
      fontSize: 12,
      fontWeight: "var(--fw-medium)",
      borderRadius: "var(--radius-sm)",
      cursor: onClick ? "pointer" : "default",
      whiteSpace: "nowrap",
      ...style
    }
  }, rest), color && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: color,
      flex: "none"
    }
  }), children, removable && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove tag",
    onClick: e => {
      e.stopPropagation();
      onRemove && onRemove();
    },
    style: {
      display: "inline-flex",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--color-text-tertiary)",
      padding: 0,
      marginRight: -2
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 13,
      height: 13
    }
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/core/Tooltip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Tooltip — hover/focus hint. CSS-positioned, no portal. */
function Tooltip({
  children,
  content,
  side = "top",
  style,
  ...rest
}) {
  const [show, setShow] = React.useState(false);
  const pos = {
    top: {
      bottom: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    bottom: {
      top: "calc(100% + 6px)",
      left: "50%",
      transform: "translateX(-50%)"
    },
    left: {
      right: "calc(100% + 6px)",
      top: "50%",
      transform: "translateY(-50%)"
    },
    right: {
      left: "calc(100% + 6px)",
      top: "50%",
      transform: "translateY(-50%)"
    }
  }[side];
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      ...style
    },
    onMouseEnter: () => setShow(true),
    onMouseLeave: () => setShow(false),
    onFocus: () => setShow(true),
    onBlur: () => setShow(false)
  }, rest), children, show && /*#__PURE__*/React.createElement("span", {
    role: "tooltip",
    style: {
      position: "absolute",
      ...pos,
      zIndex: "var(--z-tooltip)",
      background: "var(--gray-900)",
      color: "#fff",
      fontSize: 12,
      lineHeight: 1.3,
      fontWeight: "var(--fw-medium)",
      padding: "5px 8px",
      borderRadius: "var(--radius-sm)",
      boxShadow: "var(--shadow-3)",
      whiteSpace: "nowrap",
      pointerEvents: "none",
      animation: "notely-fade-in var(--duration-fast) var(--ease-standard)"
    }
  }, content));
}
Object.assign(__ds_scope, { Tooltip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tooltip.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Alert — inline contextual message banner. */
function Alert({
  tone = "info",
  title,
  children,
  onClose,
  style,
  ...rest
}) {
  const map = {
    info: {
      c: "var(--color-info)",
      bg: "var(--color-info-subtle)",
      i: "info"
    },
    success: {
      c: "var(--color-success)",
      bg: "var(--color-success-subtle)",
      i: "check-circle"
    },
    warning: {
      c: "var(--color-warning)",
      bg: "var(--color-warning-subtle)",
      i: "alert-triangle"
    },
    danger: {
      c: "var(--color-danger)",
      bg: "var(--color-danger-subtle)",
      i: "alert-circle"
    }
  };
  const t = map[tone] || map.info;
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    style: {
      display: "flex",
      gap: 10,
      padding: "12px 14px",
      background: t.bg,
      border: `1px solid ${t.c}`,
      borderRadius: "var(--radius-md)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    "data-lucide": t.i,
    style: {
      width: 18,
      height: 18,
      color: t.c,
      flex: "none",
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: "var(--fw-semibold)",
      color: "var(--color-text)"
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--color-text-secondary)",
      marginTop: title ? 2 : 0
    }
  }, children)), onClose && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onClose,
    style: {
      border: "none",
      background: "transparent",
      color: "var(--color-text-tertiary)",
      cursor: "pointer",
      padding: 2,
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 15,
      height: 15
    }
  })));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/EmptyState.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely EmptyState — friendly placeholder for empty views. */
function EmptyState({
  icon = "inbox",
  title,
  description,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      padding: "48px 24px",
      maxWidth: 360,
      margin: "0 auto",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 56,
      height: 56,
      borderRadius: "var(--radius-xl)",
      background: "var(--color-primary-subtle)",
      color: "var(--color-primary)",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: 28,
      height: 28
    }
  })), title && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: "var(--fw-semibold)",
      color: "var(--color-text)"
    }
  }, title), description && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: "var(--color-text-secondary)",
      marginTop: 6,
      lineHeight: "var(--lh-normal)"
    }
  }, description), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely ProgressBar — determinate or indeterminate. */
function ProgressBar({
  value = 0,
  indeterminate = false,
  tone = "primary",
  height = 6,
  style,
  ...rest
}) {
  const color = {
    primary: "var(--color-primary)",
    success: "var(--color-success)",
    warning: "var(--color-warning)",
    danger: "var(--color-danger)"
  }[tone];
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "progressbar",
    "aria-valuenow": indeterminate ? undefined : value,
    "aria-valuemin": 0,
    "aria-valuemax": 100,
    style: {
      width: "100%",
      height,
      background: "var(--color-bg)",
      border: "1px solid var(--color-border)",
      borderRadius: "var(--radius-full)",
      overflow: "hidden",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      background: color,
      borderRadius: "var(--radius-full)",
      width: indeterminate ? "40%" : `${Math.max(0, Math.min(100, value))}%`,
      transition: "width var(--duration-slow) var(--ease-standard)",
      animation: indeterminate ? "notely-indeterminate 1.2s var(--ease-standard) infinite" : "none"
    }
  }));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Skeleton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Skeleton — shimmer placeholder for loading content. */
function Skeleton({
  width = "100%",
  height = 14,
  radius = "var(--radius-sm)",
  circle = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "block",
      width: circle ? height : width,
      height,
      borderRadius: circle ? "50%" : radius,
      background: "linear-gradient(90deg, var(--color-bg) 25%, var(--color-border) 50%, var(--color-bg) 75%)",
      backgroundSize: "200% 100%",
      animation: "notely-shimmer 1.4s ease-in-out infinite",
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Spinner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Spinner — small indeterminate loading indicator. */
function Spinner({
  size = 18,
  color = "currentColor",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    role: "status",
    "aria-label": "Loading",
    style: {
      display: "inline-block",
      width: size,
      height: size,
      border: `2px solid ${color}`,
      borderRightColor: "transparent",
      borderRadius: "50%",
      animation: "notely-spin 0.6s linear infinite",
      opacity: 0.85,
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Toast — transient confirmation. Render inside a fixed container. */
function Toast({
  message,
  tone = "neutral",
  action,
  actionLabel,
  onAction,
  onDismiss,
  style,
  ...rest
}) {
  const icons = {
    neutral: "info",
    success: "check-circle",
    warning: "alert-triangle",
    danger: "alert-circle"
  };
  const colors = {
    neutral: "var(--color-text-secondary)",
    success: "var(--color-success)",
    warning: "var(--color-warning)",
    danger: "var(--color-danger)"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "status",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      minWidth: 260,
      maxWidth: 400,
      padding: "10px 12px",
      background: "var(--gray-900)",
      color: "#fff",
      borderRadius: "var(--radius-md)",
      boxShadow: "var(--shadow-4)",
      fontSize: 14,
      animation: "notely-fade-rise var(--duration-base) var(--ease-standard)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("i", {
    "data-lucide": icons[tone],
    style: {
      width: 18,
      height: 18,
      color: tone === "neutral" ? "#fff" : colors[tone],
      flex: "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, message), actionLabel && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onAction,
    style: {
      border: "none",
      background: "transparent",
      color: "var(--indigo-300)",
      fontWeight: "var(--fw-semibold)",
      fontSize: 14,
      cursor: "pointer",
      padding: "2px 4px"
    }
  }, actionLabel), onDismiss && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Dismiss",
    onClick: onDismiss,
    style: {
      border: "none",
      background: "transparent",
      color: "rgba(255,255,255,0.6)",
      cursor: "pointer",
      padding: 2,
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 15,
      height: 15
    }
  })));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Checkbox — supports checked, indeterminate, disabled, with optional label. */
function Checkbox({
  checked = false,
  indeterminate = false,
  label,
  disabled = false,
  onChange,
  id,
  style,
  ...rest
}) {
  const fieldId = id || React.useId();
  const on = checked || indeterminate;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--opacity-disabled)" : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 18,
      height: 18,
      flex: "none",
      background: on ? "var(--color-primary)" : "var(--color-card)",
      border: `1.5px solid ${on ? "var(--color-primary)" : "var(--color-border-strong)"}`,
      borderRadius: "var(--radius-xs)",
      color: "#fff",
      transition: "background var(--duration-fast), border-color var(--duration-fast)"
    }
  }, indeterminate ? /*#__PURE__*/React.createElement("i", {
    "data-lucide": "minus",
    style: {
      width: 13,
      height: 13
    }
  }) : checked ? /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check",
    style: {
      width: 13,
      height: 13
    }
  }) : null), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "checkbox",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--color-text)"
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Notely Input — single-line text field.
 * Supports label, helper/error text, leading/trailing adornments, sizes.
 */
function Input({
  label,
  value,
  placeholder,
  type = "text",
  size = "md",
  helperText,
  error,
  leadingIcon,
  trailingIcon,
  disabled = false,
  id,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: {
      h: 32,
      fs: 13,
      px: 10
    },
    md: {
      h: 38,
      fs: 14,
      px: 12
    },
    lg: {
      h: 44,
      fs: 15,
      px: 14
    }
  };
  const s = sizes[size] || sizes.md;
  const fieldId = id || React.useId();
  const invalid = Boolean(error);
  const borderColor = invalid ? "var(--color-danger)" : focus ? "var(--color-primary)" : "var(--color-border-strong)";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontSize: 13,
      fontWeight: "var(--fw-medium)",
      color: "var(--color-text)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      height: s.h,
      padding: `0 ${s.px}px`,
      background: disabled ? "var(--color-bg)" : "var(--color-card)",
      border: `1px solid ${borderColor}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus && !invalid ? "var(--shadow-focus)" : "none",
      transition: "border-color var(--duration-fast), box-shadow var(--duration-fast)",
      opacity: disabled ? "var(--opacity-disabled)" : 1,
      color: "var(--color-text-tertiary)"
    }
  }, leadingIcon, /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: type,
    value: value,
    placeholder: placeholder,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    "aria-invalid": invalid,
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: s.fs,
      color: "var(--color-text)"
    }
  }, rest)), trailingIcon), (helperText || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: invalid ? "var(--color-danger)" : "var(--color-text-secondary)"
    }
  }, error || helperText));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Radio — single selection within a group. */
function Radio({
  checked = false,
  label,
  name,
  value,
  disabled = false,
  onChange,
  id,
  style,
  ...rest
}) {
  const fieldId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--opacity-disabled)" : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 18,
      height: 18,
      flex: "none",
      borderRadius: "50%",
      background: "var(--color-card)",
      border: `1.5px solid ${checked ? "var(--color-primary)" : "var(--color-border-strong)"}`,
      transition: "border-color var(--duration-fast)"
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: "50%",
      background: "var(--color-primary)"
    }
  })), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--color-text)"
    }
  }, label));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely SearchField — search input with icon, clear button, optional ⌘K hint. */
function SearchField({
  value = "",
  placeholder = "Search notes",
  size = "md",
  shortcut,
  onChange,
  onClear,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: 32,
    md: 38,
    lg: 44
  };
  const h = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      height: h,
      padding: "0 10px",
      background: "var(--color-card)",
      border: `1px solid ${focus ? "var(--color-primary)" : "var(--color-border-strong)"}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "var(--shadow-focus)" : "none",
      transition: "border-color var(--duration-fast), box-shadow var(--duration-fast)",
      color: "var(--color-text-tertiary)",
      ...style
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "search",
    style: {
      width: 16,
      height: 16
    }
  }), /*#__PURE__*/React.createElement("input", _extends({
    type: "search",
    value: value,
    placeholder: placeholder,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: "var(--color-text)"
    }
  }, rest)), value ? /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Clear search",
    onClick: onClear,
    style: {
      display: "inline-flex",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--color-text-tertiary)",
      padding: 2
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 15,
      height: 15
    }
  })) : shortcut ? /*#__PURE__*/React.createElement("kbd", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "var(--color-text-tertiary)",
      background: "var(--color-bg)",
      border: "1px solid var(--color-border)",
      borderRadius: "var(--radius-sm)",
      padding: "1px 5px"
    }
  }, shortcut) : null);
}
Object.assign(__ds_scope, { SearchField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchField.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Select — styled native-backed dropdown. */
function Select({
  label,
  value,
  options = [],
  placeholder = "Select…",
  size = "md",
  disabled = false,
  onChange,
  id,
  style,
  ...rest
}) {
  const fieldId = id || React.useId();
  const [focus, setFocus] = React.useState(false);
  const sizes = {
    sm: 32,
    md: 38,
    lg: 44
  };
  const h = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      fontSize: 13,
      fontWeight: "var(--fw-medium)",
      color: "var(--color-text)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      height: h,
      background: "var(--color-card)",
      border: `1px solid ${focus ? "var(--color-primary)" : "var(--color-border-strong)"}`,
      borderRadius: "var(--radius-md)",
      boxShadow: focus ? "var(--shadow-focus)" : "none",
      opacity: disabled ? "var(--opacity-disabled)" : 1
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fieldId,
    value: value,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      appearance: "none",
      WebkitAppearance: "none",
      flex: 1,
      height: "100%",
      border: "none",
      outline: "none",
      background: "transparent",
      padding: "0 34px 0 12px",
      fontFamily: "var(--font-sans)",
      fontSize: 14,
      color: value ? "var(--color-text)" : "var(--color-text-tertiary)",
      cursor: "pointer"
    }
  }, rest), placeholder && /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true,
    hidden: true
  }, placeholder), options.map(o => {
    const opt = typeof o === "string" ? {
      value: o,
      label: o
    } : o;
    return /*#__PURE__*/React.createElement("option", {
      key: opt.value,
      value: opt.value
    }, opt.label);
  })), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevron-down",
    style: {
      position: "absolute",
      right: 10,
      width: 16,
      height: 16,
      pointerEvents: "none",
      color: "var(--color-text-tertiary)"
    }
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Switch — on/off toggle (pill). */
function Switch({
  checked = false,
  label,
  disabled = false,
  onChange,
  id,
  style,
  ...rest
}) {
  const fieldId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fieldId,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? "var(--opacity-disabled)" : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    role: "switch",
    "aria-checked": checked,
    style: {
      position: "relative",
      width: 38,
      height: 22,
      flex: "none",
      background: checked ? "var(--color-primary)" : "var(--color-border-strong)",
      borderRadius: "var(--radius-full)",
      transition: "background var(--duration-base) var(--ease-standard)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: checked ? 18 : 2,
      width: 18,
      height: 18,
      background: "#fff",
      borderRadius: "50%",
      boxShadow: "var(--shadow-1)",
      transition: "left var(--duration-base) var(--ease-standard)"
    }
  })), /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    type: "checkbox",
    role: "switch",
    checked: checked,
    disabled: disabled,
    onChange: onChange,
    style: {
      position: "absolute",
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--color-text)"
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/layout/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Card — surface container. Optional hover-lift and clickable. */
function Card({
  children,
  padding = 16,
  interactive = false,
  elevation = 1,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const shadow = `var(--shadow-${interactive && hover ? Math.min(elevation + 1, 5) : elevation})`;
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      background: "var(--color-card)",
      border: `1px solid ${interactive && hover ? "var(--color-border-strong)" : "var(--color-border)"}`,
      borderRadius: "var(--radius-lg)",
      boxShadow: shadow,
      padding,
      cursor: interactive ? "pointer" : "default",
      transition: "box-shadow var(--duration-base) var(--ease-standard), border-color var(--duration-base)",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Card.jsx", error: String((e && e.message) || e) }); }

// components/layout/Modal.jsx
try { (() => {
/** Notely Modal — centered dialog with backdrop. Esc + backdrop click to close. */
function Modal({
  open,
  title,
  children,
  footer,
  size = "md",
  onClose
}) {
  React.useEffect(() => {
    if (!open) return;
    const onKey = e => e.key === "Escape" && onClose && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [open, onClose]);
  if (!open) return null;
  const widths = {
    sm: 380,
    md: 480,
    lg: 640
  };
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: "var(--z-modal)",
      background: "var(--color-overlay)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 16,
      backdropFilter: "blur(2px)",
      animation: "notely-fade-in var(--duration-fast) var(--ease-standard)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title,
    onClick: e => e.stopPropagation(),
    style: {
      width: "100%",
      maxWidth: widths[size] || widths.md,
      background: "var(--color-card)",
      borderRadius: "var(--radius-xl)",
      boxShadow: "var(--shadow-4)",
      overflow: "hidden",
      animation: "notely-scale-in var(--duration-base) var(--ease-standard)"
    }
  }, title && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "16px 20px",
      borderBottom: "1px solid var(--color-divider)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: "var(--fw-semibold)",
      color: "var(--color-text)"
    }
  }, title), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Close",
    onClick: onClose,
    style: {
      display: "inline-flex",
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: "var(--color-text-tertiary)",
      padding: 4
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "x",
    style: {
      width: 18,
      height: 18
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 20,
      fontSize: 14,
      color: "var(--color-text-secondary)",
      lineHeight: "var(--lh-normal)"
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      gap: 8,
      padding: "12px 20px",
      borderTop: "1px solid var(--color-divider)"
    }
  }, footer)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Modal.jsx", error: String((e && e.message) || e) }); }

// components/layout/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely Tabs — underline tab bar. Controlled via value/onChange. */
function Tabs({
  tabs = [],
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    style: {
      display: "flex",
      gap: 4,
      borderBottom: "1px solid var(--color-divider)",
      ...style
    }
  }, rest), tabs.map(t => {
    const tab = typeof t === "string" ? {
      value: t,
      label: t
    } : t;
    const active = tab.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: tab.value,
      role: "tab",
      "aria-selected": active,
      onClick: () => onChange && onChange(tab.value),
      style: {
        position: "relative",
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "9px 12px",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontFamily: "var(--font-sans)",
        fontSize: 14,
        fontWeight: active ? "var(--fw-semibold)" : "var(--fw-medium)",
        color: active ? "var(--color-text)" : "var(--color-text-secondary)",
        transition: "color var(--duration-fast)"
      }
    }, tab.icon, tab.label, tab.count != null && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--color-text-tertiary)"
      }
    }, tab.count), /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: 8,
        right: 8,
        bottom: -1,
        height: 2,
        borderRadius: "var(--radius-full)",
        background: active ? "var(--color-primary)" : "transparent",
        transition: "background var(--duration-fast)"
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/layout/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/notes/ChecklistItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely ChecklistItem — a to-do row inside a note. */
function ChecklistItem({
  checked = false,
  text,
  onToggle,
  onChange,
  editable = false,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 10,
      padding: "3px 0",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "checkbox",
    "aria-checked": checked,
    onClick: onToggle,
    style: {
      marginTop: 2,
      flex: "none",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: 18,
      height: 18,
      borderRadius: "var(--radius-xs)",
      background: checked ? "var(--color-primary)" : "var(--color-card)",
      border: `1.5px solid ${checked ? "var(--color-primary)" : "var(--color-border-strong)"}`,
      color: "#fff",
      cursor: "pointer",
      transition: "background var(--duration-fast)"
    }
  }, checked && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check",
    style: {
      width: 13,
      height: 13
    }
  })), editable ? /*#__PURE__*/React.createElement("input", {
    value: text,
    onChange: onChange,
    style: {
      flex: 1,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: 15,
      color: checked ? "var(--color-text-tertiary)" : "var(--color-text)",
      textDecoration: checked ? "line-through" : "none"
    }
  }) : /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 15,
      lineHeight: "var(--lh-normal)",
      color: checked ? "var(--color-text-tertiary)" : "var(--color-text)",
      textDecoration: checked ? "line-through" : "none"
    }
  }, text));
}
Object.assign(__ds_scope, { ChecklistItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/notes/ChecklistItem.jsx", error: String((e && e.message) || e) }); }

// components/notes/EditorToolbar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely EditorToolbar — rich-text formatting bar for the note editor. */
function EditorToolbar({
  active = {},
  onAction,
  style,
  ...rest
}) {
  const groups = [[["bold", "Bold"], ["italic", "Italic"], ["underline", "Underline"], ["strikethrough", "Strikethrough"]], [["heading-1", "Heading 1"], ["heading-2", "Heading 2"], ["quote", "Quote"]], [["list", "Bullet list"], ["list-ordered", "Numbered list"], ["list-checks", "Checklist"]], [["link", "Link"], ["code", "Code"], ["image", "Image"]]];
  const Btn = ({
    name,
    label
  }) => {
    const [hover, setHover] = React.useState(false);
    const on = active[name];
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      "aria-label": label,
      title: label,
      onClick: () => onAction && onAction(name),
      onMouseEnter: () => setHover(true),
      onMouseLeave: () => setHover(false),
      style: {
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: 32,
        height: 32,
        border: "none",
        borderRadius: "var(--radius-sm)",
        background: on ? "var(--color-selected)" : hover ? "var(--color-hover)" : "transparent",
        color: on ? "var(--color-primary)" : "var(--color-text-secondary)",
        cursor: "pointer",
        transition: "background var(--duration-fast)"
      }
    }, /*#__PURE__*/React.createElement("i", {
      "data-lucide": name,
      style: {
        width: 17,
        height: 17
      }
    }));
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "toolbar",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2,
      flexWrap: "wrap",
      padding: 4,
      background: "var(--color-card)",
      border: "1px solid var(--color-border)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-1)",
      ...style
    }
  }, rest), groups.map((g, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, g.map(([name, label]) => /*#__PURE__*/React.createElement(Btn, {
    key: name,
    name: name,
    label: label
  })), i < groups.length - 1 && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: 20,
      background: "var(--color-divider)",
      margin: "0 4px"
    }
  }))));
}
Object.assign(__ds_scope, { EditorToolbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/notes/EditorToolbar.jsx", error: String((e && e.message) || e) }); }

// components/notes/FolderItem.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Notely FolderItem — sidebar folder row with count and selected state. */
function FolderItem({
  name,
  count,
  color,
  icon = "folder",
  active = false,
  depth = 0,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      width: "100%",
      padding: "7px 10px",
      paddingLeft: 10 + depth * 16,
      border: "none",
      borderRadius: "var(--radius-md)",
      background: active ? "var(--color-selected)" : hover ? "var(--color-hover)" : "transparent",
      color: active ? "var(--color-primary)" : "var(--color-text-secondary)",
      cursor: "pointer",
      textAlign: "left",
      fontFamily: "var(--font-sans)",
      transition: "background var(--duration-fast)",
      ...style
    }
  }, rest), color ? /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: "50%",
      background: color,
      flex: "none"
    }
  }) : /*#__PURE__*/React.createElement("i", {
    "data-lucide": icon,
    style: {
      width: 16,
      height: 16,
      flex: "none"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 14,
      fontWeight: active ? "var(--fw-semibold)" : "var(--fw-medium)",
      color: active ? "var(--color-text)" : "inherit",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, name), count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--color-text-tertiary)"
    }
  }, count));
}
Object.assign(__ds_scope, { FolderItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/notes/FolderItem.jsx", error: String((e && e.message) || e) }); }

// components/notes/NoteCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Notely NoteCard — a note preview tile (grid or list).
 * Shows title, snippet, meta, tags, and pin/favorite affordances.
 */
function NoteCard({
  title = "Untitled",
  snippet = "",
  date,
  folder,
  tags = [],
  pinned = false,
  favorite = false,
  color,
  selected = false,
  layout = "grid",
  onClick,
  onTogglePin,
  onToggleFavorite,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const isList = layout === "list";
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "flex",
      flexDirection: isList ? "row" : "column",
      alignItems: isList ? "center" : "stretch",
      gap: isList ? 14 : 10,
      padding: isList ? "12px 14px" : 16,
      background: selected ? "var(--color-selected)" : "var(--color-card)",
      border: `1px solid ${selected ? "var(--color-primary)" : hover ? "var(--color-border-strong)" : "var(--color-border)"}`,
      borderRadius: "var(--radius-lg)",
      boxShadow: hover ? "var(--shadow-2)" : "var(--shadow-1)",
      cursor: "pointer",
      transition: "box-shadow var(--duration-base) var(--ease-standard), border-color var(--duration-base)",
      ...style
    }
  }, rest), color && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      left: 0,
      top: 14,
      bottom: 14,
      width: 3,
      borderRadius: "var(--radius-full)",
      background: color,
      display: isList ? "block" : "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      marginBottom: 4
    }
  }, pinned && /*#__PURE__*/React.createElement("i", {
    "data-lucide": "pin",
    style: {
      width: 14,
      height: 14,
      color: "var(--color-primary)",
      transform: "rotate(45deg)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: "var(--fw-semibold)",
      color: "var(--color-text)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, title)), snippet && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: "var(--color-text-secondary)",
      lineHeight: "var(--lh-normal)",
      display: "-webkit-box",
      WebkitLineClamp: isList ? 1 : 3,
      WebkitBoxOrient: "vertical",
      overflow: "hidden"
    }
  }, snippet), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginTop: isList ? 4 : 12,
      flexWrap: "wrap"
    }
  }, date && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--color-text-tertiary)"
    }
  }, date), folder && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--color-text-tertiary)",
      display: "inline-flex",
      alignItems: "center",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "folder",
    style: {
      width: 12,
      height: 12
    }
  }), folder), tags.slice(0, isList ? 2 : 3).map(t => /*#__PURE__*/React.createElement(__ds_scope.Tag, {
    key: t.label || t,
    color: t.color
  }, t.label || t)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 2,
      opacity: hover || favorite || pinned ? 1 : 0,
      transition: "opacity var(--duration-fast)",
      alignSelf: isList ? "center" : "flex-start",
      position: isList ? "static" : "absolute",
      top: 12,
      right: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Favorite",
    onClick: e => {
      e.stopPropagation();
      onToggleFavorite && onToggleFavorite();
    },
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: favorite ? "var(--color-warning)" : "var(--color-text-tertiary)",
      padding: 4,
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "star",
    style: {
      width: 16,
      height: 16,
      fill: favorite ? "var(--color-warning)" : "none"
    }
  })), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Pin",
    onClick: e => {
      e.stopPropagation();
      onTogglePin && onTogglePin();
    },
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      color: pinned ? "var(--color-primary)" : "var(--color-text-tertiary)",
      padding: 4,
      display: "inline-flex"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "pin",
    style: {
      width: 16,
      height: 16,
      fill: pinned ? "var(--color-primary)" : "none"
    }
  }))));
}
Object.assign(__ds_scope, { NoteCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/notes/NoteCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notely-app/App.jsx
try { (() => {
// Notely UI kit — top-level app shell + state.
function NotelyApp() {
  const [theme, setTheme] = React.useState("light");
  const [active, setActive] = React.useState("all");
  const [query, setQuery] = React.useState("");
  const [layout, setLayout] = React.useState("grid");
  const [openId, setOpenId] = React.useState(null);
  const [toast, setToast] = React.useState(null);
  React.useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  const notes = window.NotelyData.notes.filter(n => query === "" ? true : (n.title + " " + n.snippet).toLowerCase().includes(query.toLowerCase()));
  const openNote = window.NotelyData.notes.find(n => n.id === openId);
  function newNote() {
    setToast("New note created");
    setTimeout(() => setToast(null), 2400);
  }
  let view;
  if (active === "settings") {
    view = /*#__PURE__*/React.createElement(window.SettingsView, {
      dark: theme === "dark",
      onToggleTheme: () => setTheme(t => t === "dark" ? "light" : "dark")
    });
  } else if (openNote) {
    view = /*#__PURE__*/React.createElement(window.EditorView, {
      note: openNote,
      onBack: () => setOpenId(null)
    });
  } else {
    view = /*#__PURE__*/React.createElement(window.NotesView, {
      notes: notes,
      query: query,
      onQuery: setQuery,
      layout: layout,
      onLayout: setLayout,
      onOpen: setOpenId
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      height: "100vh",
      overflow: "hidden",
      fontFamily: "var(--font-sans)"
    }
  }, /*#__PURE__*/React.createElement(window.Sidebar, {
    active: active,
    onSelect: id => {
      setActive(id);
      setOpenId(null);
    },
    onNew: newNote
  }), view, toast && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "fixed",
      bottom: 24,
      left: "50%",
      transform: "translateX(-50%)",
      zIndex: 1300
    }
  }, /*#__PURE__*/React.createElement(window.NotelyDesignSystem_fd4cb3.Toast, {
    message: toast,
    tone: "success",
    onDismiss: () => setToast(null)
  })));
}
window.NotelyApp = NotelyApp;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notely-app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notely-app/EditorView.jsx
try { (() => {
// Notely UI kit — full-page note editor.
const {
  IconButton,
  Button,
  Tag,
  EditorToolbar,
  ChecklistItem,
  Avatar
} = window.NotelyDesignSystem_fd4cb3;
function EditorView({
  note,
  onBack
}) {
  const [checks, setChecks] = React.useState({
    a: false,
    b: true
  });
  if (!note) return null;
  return /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      height: "100%",
      display: "flex",
      flexDirection: "column",
      background: "var(--color-bg)"
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "12px 20px",
      borderBottom: "1px solid var(--color-border)"
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "arrow-left",
      style: {
        width: 18,
        height: 18
      }
    }),
    label: "Back",
    onClick: onBack
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--color-text-tertiary)"
    }
  }, note.folder, " \xB7 Edited ", note.date), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 5,
      fontSize: 12,
      color: "var(--color-success)",
      marginRight: 4
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "check",
    style: {
      width: 14,
      height: 14
    }
  }), " Saved"), /*#__PURE__*/React.createElement(IconButton, {
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "star",
      style: {
        width: 18,
        height: 18,
        fill: note.favorite ? "var(--color-warning)" : "none"
      }
    }),
    label: "Favorite",
    active: note.favorite
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "pin",
      style: {
        width: 18,
        height: 18,
        fill: note.pinned ? "var(--color-primary)" : "none"
      }
    }),
    label: "Pin",
    active: note.pinned
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm",
    leadingIcon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "share-2",
      style: {
        width: 15,
        height: 15
      }
    })
  }, "Share"), /*#__PURE__*/React.createElement(IconButton, {
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "more-horizontal",
      style: {
        width: 18,
        height: 18
      }
    }),
    label: "More"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 720,
      margin: "0 auto",
      padding: "40px 32px 80px"
    }
  }, /*#__PURE__*/React.createElement("input", {
    defaultValue: note.title,
    style: {
      width: "100%",
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: 34,
      fontWeight: 700,
      letterSpacing: "-0.02em",
      color: "var(--color-text)",
      marginBottom: 12
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      marginBottom: 20
    }
  }, note.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t.label,
    color: t.color,
    removable: true
  }, t.label)), /*#__PURE__*/React.createElement(Tag, {
    onClick: () => {}
  }, "+ Add tag")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement(EditorToolbar, {
    active: {
      bold: false
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 17,
      lineHeight: "var(--lh-relaxed)",
      color: "var(--color-text)",
      whiteSpace: "pre-wrap"
    }
  }, note.body), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      paddingTop: 20,
      borderTop: "1px solid var(--color-divider)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--color-text-secondary)",
      marginBottom: 8
    }
  }, "Action items"), /*#__PURE__*/React.createElement(ChecklistItem, {
    checked: checks.a,
    text: "Polish sync conflict UI",
    onToggle: () => setChecks(c => ({
      ...c,
      a: !c.a
    }))
  }), /*#__PURE__*/React.createElement(ChecklistItem, {
    checked: checks.b,
    text: "Share recap with the team",
    onToggle: () => setChecks(c => ({
      ...c,
      b: !c.b
    }))
  })))));
}
window.EditorView = EditorView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notely-app/EditorView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notely-app/NotesView.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Notely UI kit — notes list/grid view with top bar.
const {
  NoteCard,
  SearchField,
  Select,
  IconButton,
  Tabs
} = window.NotelyDesignSystem_fd4cb3;
function NotesView({
  notes,
  onOpen,
  query,
  onQuery,
  layout,
  onLayout
}) {
  const pinned = notes.filter(n => n.pinned);
  const others = notes.filter(n => !n.pinned);
  const Grid = ({
    items
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: layout === "grid" ? "repeat(auto-fill, minmax(240px, 1fr))" : "1fr",
      gap: 12
    }
  }, items.map(n => /*#__PURE__*/React.createElement(NoteCard, _extends({
    key: n.id
  }, n, {
    layout: layout,
    onClick: () => onOpen(n.id)
  }))));
  return /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      height: "100%",
      display: "flex",
      flexDirection: "column",
      background: "var(--color-bg)"
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "14px 24px",
      borderBottom: "1px solid var(--color-border)",
      background: "var(--color-bg)"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 700,
      color: "var(--color-text)",
      letterSpacing: "-0.01em"
    }
  }, "All notes"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--color-text-tertiary)"
    }
  }, notes.length, " notes \xB7 synced just now")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 260
    }
  }, /*#__PURE__*/React.createElement(SearchField, {
    value: query,
    onChange: e => onQuery(e.target.value),
    onClear: () => onQuery(""),
    shortcut: "\u2318K"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 168
    }
  }, /*#__PURE__*/React.createElement(Select, {
    value: "recent",
    options: [{
      value: "recent",
      label: "Recently edited"
    }, {
      value: "created",
      label: "Date created"
    }, {
      value: "title",
      label: "Title A–Z"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 2,
      background: "var(--color-surface)",
      borderRadius: "var(--radius-md)",
      border: "1px solid var(--color-border)",
      padding: 2
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "layout-grid",
      style: {
        width: 16,
        height: 16
      }
    }),
    label: "Grid",
    size: "sm",
    active: layout === "grid",
    onClick: () => onLayout("grid")
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "list",
      style: {
        width: 16,
        height: 16
      }
    }),
    label: "List",
    size: "sm",
    active: layout === "list",
    onClick: () => onLayout("list")
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: 24
    }
  }, pinned.length > 0 && query === "" && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      marginBottom: 12,
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      color: "var(--color-text-tertiary)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "pin",
    style: {
      width: 13,
      height: 13
    }
  }), " Pinned"), /*#__PURE__*/React.createElement(Grid, {
    items: pinned
  })), others.length > 0 && /*#__PURE__*/React.createElement("div", null, pinned.length > 0 && query === "" && /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 12,
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      color: "var(--color-text-tertiary)"
    }
  }, "Others"), /*#__PURE__*/React.createElement(Grid, {
    items: others
  })), notes.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      color: "var(--color-text-secondary)",
      paddingTop: 80,
      fontSize: 14
    }
  }, "No notes match \"", query, "\"")));
}
window.NotesView = NotesView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notely-app/NotesView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notely-app/SettingsView.jsx
try { (() => {
// Notely UI kit — settings screen.
const {
  Switch,
  Select,
  Avatar,
  Button,
  Divider
} = window.NotelyDesignSystem_fd4cb3;
function Row({
  title,
  desc,
  control
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      padding: "14px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: "var(--color-text)"
    }
  }, title), desc && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--color-text-secondary)",
      marginTop: 2
    }
  }, desc)), control);
}
function SettingsView({
  dark,
  onToggleTheme
}) {
  return /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      minWidth: 0,
      height: "100%",
      overflowY: "auto",
      background: "var(--color-bg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      margin: "0 auto",
      padding: "40px 32px 80px"
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 27,
      fontWeight: 700,
      letterSpacing: "-0.02em",
      color: "var(--color-text)",
      margin: "0 0 24px"
    }
  }, "Settings"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      padding: 16,
      background: "var(--color-card)",
      border: "1px solid var(--color-border)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-1)"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Maya Chen",
    size: "lg",
    status: "online"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "var(--color-text)"
    }
  }, "Maya Chen"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--color-text-secondary)"
    }
  }, "maya@notely.app \xB7 Free plan")), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "sm"
  }, "Upgrade")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      color: "var(--color-text-tertiary)"
    }
  }, "Appearance"), /*#__PURE__*/React.createElement(Row, {
    title: "Dark theme",
    desc: "Use a darker palette in low light.",
    control: /*#__PURE__*/React.createElement(Switch, {
      checked: dark,
      onChange: onToggleTheme
    })
  }), /*#__PURE__*/React.createElement(Divider, {
    spacing: 0
  }), /*#__PURE__*/React.createElement(Row, {
    title: "Default view",
    desc: "How notes are laid out on open.",
    control: /*#__PURE__*/React.createElement("div", {
      style: {
        width: 150
      }
    }, /*#__PURE__*/React.createElement(Select, {
      value: "grid",
      options: [{
        value: "grid",
        label: "Grid"
      }, {
        value: "list",
        label: "List"
      }]
    }))
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      fontSize: 12,
      fontWeight: 600,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      color: "var(--color-text-tertiary)"
    }
  }, "Sync & backup"), /*#__PURE__*/React.createElement(Row, {
    title: "Sync across devices",
    desc: "Keep notes up to date everywhere.",
    control: /*#__PURE__*/React.createElement(Switch, {
      checked: true,
      onChange: () => {}
    })
  }), /*#__PURE__*/React.createElement(Divider, {
    spacing: 0
  }), /*#__PURE__*/React.createElement(Row, {
    title: "Offline mode",
    desc: "Edit without a connection; sync later.",
    control: /*#__PURE__*/React.createElement(Switch, {
      checked: true,
      onChange: () => {}
    })
  })));
}
window.SettingsView = SettingsView;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notely-app/SettingsView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notely-app/Sidebar.jsx
try { (() => {
// Notely UI kit — left sidebar (nav, folders, tags).
const {
  FolderItem,
  Avatar,
  Button
} = window.NotelyDesignSystem_fd4cb3;
function SidebarSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 10px 6px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      color: "var(--color-text-tertiary)"
    }
  }, label)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, children));
}
function Sidebar({
  active,
  onSelect,
  onNew
}) {
  const d = window.NotelyData;
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 244,
      flex: "none",
      height: "100%",
      boxSizing: "border-box",
      display: "flex",
      flexDirection: "column",
      background: "var(--color-surface)",
      borderRight: "1px solid var(--color-border)",
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      padding: "4px 8px 14px"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 8,
      background: "var(--color-primary)",
      color: "#fff",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 700,
      fontSize: 15
    }
  }, "N"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 700,
      color: "var(--color-text)",
      letterSpacing: "-0.01em"
    }
  }, "Notely"), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "chevrons-up-down",
    style: {
      width: 15,
      height: 15,
      color: "var(--color-text-tertiary)",
      marginLeft: "auto"
    }
  })), /*#__PURE__*/React.createElement(Button, {
    leadingIcon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": "plus",
      style: {
        width: 16,
        height: 16
      }
    }),
    fullWidth: true,
    onClick: onNew
  }, "New note"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: "flex",
      flexDirection: "column",
      gap: 1
    }
  }, d.folders.map(f => /*#__PURE__*/React.createElement(FolderItem, {
    key: f.id,
    name: f.name,
    icon: f.icon,
    count: f.count,
    active: active === f.id,
    onClick: () => onSelect(f.id)
  }))), /*#__PURE__*/React.createElement(SidebarSection, {
    label: "Folders"
  }, d.myFolders.map(f => /*#__PURE__*/React.createElement(FolderItem, {
    key: f.id,
    name: f.name,
    color: f.color,
    count: f.count,
    active: active === f.id,
    onClick: () => onSelect(f.id)
  })), /*#__PURE__*/React.createElement(FolderItem, {
    name: "New folder",
    icon: "plus"
  })), /*#__PURE__*/React.createElement(SidebarSection, {
    label: "Tags"
  }, d.tags.map(t => /*#__PURE__*/React.createElement("div", {
    key: t.label,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "7px 10px",
      fontSize: 14,
      color: "var(--color-text-secondary)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--color-text-tertiary)"
    }
  }, "#"), t.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "auto",
      paddingTop: 12
    }
  }, /*#__PURE__*/React.createElement(FolderItem, {
    name: "Trash",
    icon: "trash-2"
  }), /*#__PURE__*/React.createElement(FolderItem, {
    name: "Settings",
    icon: "settings",
    onClick: () => onSelect("settings"),
    active: active === "settings"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      padding: "10px 8px 4px",
      marginTop: 6,
      borderTop: "1px solid var(--color-divider)"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Maya Chen",
    size: "sm",
    status: "online"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--color-text)"
    }
  }, "Maya Chen"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: "var(--color-text-tertiary)"
    }
  }, "Free plan")), /*#__PURE__*/React.createElement("i", {
    "data-lucide": "cloud",
    style: {
      width: 15,
      height: 15,
      color: "var(--color-success)"
    }
  }))));
}
window.Sidebar = Sidebar;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notely-app/Sidebar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/notely-app/data.js
try { (() => {
// Notely UI kit — sample data (fake content for the recreation).
window.NotelyData = {
  folders: [{
    id: "all",
    name: "All notes",
    icon: "layout-grid",
    count: 12
  }, {
    id: "recent",
    name: "Recent",
    icon: "clock",
    count: 5
  }, {
    id: "fav",
    name: "Favorites",
    icon: "star",
    count: 3
  }, {
    id: "shared",
    name: "Shared with me",
    icon: "users",
    count: 2
  }],
  myFolders: [{
    id: "personal",
    name: "Personal",
    color: "#4f46e5",
    count: 6
  }, {
    id: "work",
    name: "Work",
    color: "#0d9488",
    count: 4
  }, {
    id: "ideas",
    name: "Ideas",
    color: "#d97706",
    count: 2
  }],
  tags: [{
    label: "writing",
    color: "#4f46e5"
  }, {
    label: "research",
    color: "#0d9488"
  }, {
    label: "todo",
    color: "#d97706"
  }],
  notes: [{
    id: 1,
    title: "Weekly review — June",
    snippet: "Three wins, one lesson, and the single most important thing to focus on next week. Shipping the editor felt great.",
    date: "2 min ago",
    folder: "Work",
    tags: [{
      label: "writing",
      color: "#4f46e5"
    }],
    pinned: true,
    favorite: true,
    color: "#4f46e5",
    body: "Three wins, one lesson, and the single most important thing to focus on next week.\n\nShipping the editor felt great — the team rallied and we cut scope intelligently.\n\nNext week: polish sync conflicts."
  }, {
    id: 2,
    title: "Q3 product roadmap",
    snippet: "Themes: speed, collaboration, and offline. Each theme gets one headline feature and two supporting bets.",
    date: "1 hr ago",
    folder: "Work",
    tags: [{
      label: "research",
      color: "#0d9488"
    }],
    pinned: true,
    favorite: false,
    color: "#0d9488",
    body: "Themes: speed, collaboration, and offline.\n\nEach theme gets one headline feature and two supporting bets."
  }, {
    id: 3,
    title: "Reading list",
    snippet: "Books and essays worth a second pass this quarter. Mostly design + systems thinking.",
    date: "Yesterday",
    folder: "Personal",
    tags: [],
    pinned: false,
    favorite: true,
    color: "#4f46e5",
    body: "Books and essays worth a second pass this quarter."
  }, {
    id: 4,
    title: "Trip planning — Lisbon",
    snippet: "Neighborhoods, day trips, and a short list of places to eat. Flexible itinerary, no overbooking.",
    date: "Mon",
    folder: "Personal",
    tags: [{
      label: "todo",
      color: "#d97706"
    }],
    pinned: false,
    favorite: false,
    color: "#d97706",
    body: "Neighborhoods, day trips, and a short list of places to eat."
  }, {
    id: 5,
    title: "Meeting notes — sync",
    snippet: "Decisions, owners, and follow-ups from the weekly sync. Archived after action items closed.",
    date: "Mar 4",
    folder: "Work",
    tags: [],
    pinned: false,
    favorite: false,
    color: "#0d9488",
    body: "Decisions, owners, and follow-ups from the weekly sync."
  }, {
    id: 6,
    title: "App ideas",
    snippet: "A running list of small tools I'd actually use. Filter by effort vs. delight.",
    date: "Mar 1",
    folder: "Ideas",
    tags: [{
      label: "writing",
      color: "#4f46e5"
    }],
    pinned: false,
    favorite: false,
    color: "#d97706",
    body: "A running list of small tools I'd actually use."
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/notely-app/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Divider = __ds_scope.Divider;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Tooltip = __ds_scope.Tooltip;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.SearchField = __ds_scope.SearchField;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Modal = __ds_scope.Modal;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.ChecklistItem = __ds_scope.ChecklistItem;

__ds_ns.EditorToolbar = __ds_scope.EditorToolbar;

__ds_ns.FolderItem = __ds_scope.FolderItem;

__ds_ns.NoteCard = __ds_scope.NoteCard;

})();
