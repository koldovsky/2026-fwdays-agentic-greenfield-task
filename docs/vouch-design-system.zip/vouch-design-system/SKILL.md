---
name: cv-agent-design
description: Use this skill to generate well-branded interfaces and assets for CV-Agent, an honest AI-powered resume tailor. Contains essential design guidelines, color tokens, type system, component library, and UI kit for the CV-Agent product. Use for production code or throwaway prototypes/mocks.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

Key brand rules to always follow:
- Colors: navy ink `#16243d`, brand blue `#3257c5`, warm paper `#faf7f2`. Never add new brand hues.
- Type: Bricolage Grotesque for display/headlines, Hanken Grotesk for body/UI (both Google Fonts).
- Status colors are fixed: met `#2f8f5b`, partial `#c79a1e`, gap `#d05151`, overclaim-risk `#e08a3c`.
- Copy is direct, calm, honest. No exclamation points. No emoji. No invented claims.
- Cards: white bg, hairline border, 14–20px radius. No colored left-border accents.
- Icons: colored dot indicators and arrow characters only. No icon libraries.

If the user invokes this skill without other guidance, ask them what they want to build or design, ask some clarifying questions about surface/fidelity/content, and act as an expert designer outputting HTML artifacts or production code as appropriate.
